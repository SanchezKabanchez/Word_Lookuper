"""Network permissions and diagnostic-log controls for the settings window."""
runtime = None


def configure(application):
    global runtime
    runtime = application


class PrivacySettingsMixin:
    def _build_network_settings(self, parent):
        box = runtime.ttk.LabelFrame(parent, text="Мережа й джерела даних", padding=10)
        box.pack(fill="x", pady=(12, 0))
        runtime.ttk.Label(box, text="Онлайн-пошук надсилає слово, а для перекладу контексту — речення. "
                          "Знімки екрана залишаються локально. Вимкнене джерело не отримує нових запитів; "
                          "уже надісланий запит може завершитися.", wraplength=520).pack(anchor="w")
        runtime.ttk.Checkbutton(box, text="Офлайн — лише локальний словник, бібліотека й кеш",
                               variable=self._var(runtime.tk.BooleanVar, ("network", "offline"))
                               ).pack(anchor="w", pady=(8, 4))
        for key, label in (("google", "Google (неофіційні адреси, доступність може змінюватися)"),
                           ("mymemory", "MyMemory"), ("datamuse", "Datamuse (слова й синоніми)"),
                           ("dictionaryapi", "dictionaryapi.dev (визначення й аудіо)"),
                           ("deepl", "DeepL (потрібен увімкнений ключ нижче)")):
            runtime.ttk.Checkbutton(box, text=label, variable=self._var(
                runtime.tk.BooleanVar, ("network", "providers", key))).pack(anchor="w", pady=2)
        buttons = runtime.ttk.Frame(box)
        buttons.pack(anchor="w", pady=(8, 0))
        for label, mode in (("Усі джерела", "all"), ("Лише DeepL", "deepl"), ("Лише локально", "offline")):
            runtime.ttk.Button(buttons, text=label, command=lambda m=mode: self._network_preset(m)
                               ).pack(side="left", padx=(0, 6))

    def _network_preset(self, mode):
        offline = mode == "offline"
        path = ("network", "offline")
        self._setting_vars[path].set(offline)
        for provider in runtime.cfg["network"]["providers"]:
            self._setting_vars[("network", "providers", provider)].set(mode == "all" or provider == "deepl")
        self._schedule_config_save()

    def copy_log(self):
        if not runtime.messagebox.askyesno(runtime.APP_NAME,
                "Звіт містить шукані слова, частини речень і налаштування. Ключ DeepL приховано. "
                "Переглянь текст перед надсиланням іншій людині. Скопіювати звіт?", parent=self.root):
            return
        report = runtime.diagnostic_report()
        try:
            runtime.pyperclip.copy(report)
        except Exception as error:
            runtime.messagebox.showinfo(runtime.APP_NAME, f"Не вдалося скопіювати: {error}")
            return
        runtime.messagebox.showinfo(runtime.APP_NAME, "Звіт скопійовано. Переглянь його перед надсиланням.")

    def open_log(self):
        if not runtime.os.path.exists(runtime.log_path()):
            runtime.messagebox.showinfo(runtime.APP_NAME, "Журнал ще порожній.")
            return
        runtime.open_file(runtime.log_path())

    def clear_log(self):
        try:
            runtime.clear_log()
        except OSError as error:
            runtime.messagebox.showerror(runtime.APP_NAME, f"Не вдалося очистити журнал: {error}")
            return
        runtime.messagebox.showinfo(runtime.APP_NAME, "Журнал і його попередню копію очищено.")

    def _build_ocr_budget_settings(self, parent):
        box = runtime.ttk.LabelFrame(parent, text="Навантаження OCR", padding=10)
        box.pack(fill="x", pady=(12, 0))
        options = ((('ocr', 'cpu_threads'), 'Потоків CPU для OCR', 1, 4, 1),
                   (('ocr', 'max_side'), 'Максимальна сторона OCR-знімка, px', 640, 3200, 160),
                   (('performance', 'hover_delay_ms'), 'Затримка наведення перед OCR, мс', 100, 1000, 50))
        for row, (path, label, low, high, step) in enumerate(options):
            runtime.ttk.Label(box, text=label).grid(row=row, column=0, sticky='w', pady=3)
            runtime.ttk.Spinbox(box, from_=low, to=high, increment=step, width=7,
                textvariable=self._var(runtime.tk.IntVar, path)).grid(row=row, column=1, sticky='w', padx=8)
        runtime.ttk.Checkbutton(box, text='Для вибору слова захоплювати лише активний монітор',
            variable=self._var(runtime.tk.BooleanVar, ('performance', 'capture_active_monitor'))
        ).grid(row=3, column=0, columnspan=2, sticky='w', pady=(6, 0))
        runtime.ttk.Label(box, text='Типово 2 потоки й один OCR-прохід за раз. Для слабшого ПК можна вибрати 1. '
            'Менший знімок економить CPU, але може погіршити розпізнавання дрібного тексту. '
            'Параметри застосовуються до наступного OCR; вже запущений прохід завершується.',
            foreground='#a2a8b8', wraplength=520, justify='left'
        ).grid(row=4, column=0, columnspan=2, sticky='w', pady=(5, 0))
