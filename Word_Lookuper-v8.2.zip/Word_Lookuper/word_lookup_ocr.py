"""OCR engines, capture geometry, word and sentence recognition.

The runtime supplies configuration, shared state and overridable service adapters.
The entry point reexports this API for existing integrations.
"""
from __future__ import annotations

import csv
import io
import os

from wl_network import LookupCancelled, check_cancelled
from word_lookup_ocr_budget import (cpu_threads, max_side, bounded_number,
                                    fit_image, ocr_slot, create_rapid_engine)

runtime = None
_rapid_settings = None


def configure(application):
    global runtime
    runtime = application


class OcrError(Exception):
    pass


def _default_tesseract() -> str:
    if runtime.sys.platform.startswith("win"):
        for p in (r"C:\Program Files\Tesseract-OCR\tesseract.exe",
                  r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe"):
            if runtime.os.path.exists(p):
                return p
    return ""


def _configure_tesseract_cmd():
    """Підключає pytesseract і виставляє шлях до tesseract.exe. Не звертається до
    самого tesseract (без subprocess) — це швидко й безпечно викликати часто."""
    try:
        import pytesseract
    except ImportError:
        return None
    cmd = runtime.ocr_settings()["tesseract_cmd"] or runtime._default_tesseract()
    if cmd:
        pytesseract.pytesseract.tesseract_cmd = cmd
    return pytesseract


def tesseract_ready() -> bool:
    """Чи можна реально запустити tesseract. Виконує subprocess із жорстким
    тайм-аутом 2 с, щоб зламаний чи заблокований (антивірусом) шлях ніколи не
    підвісив програму — раніше тут не було тайм-ауту взагалі."""
    pytesseract = runtime._configure_tesseract_cmd()
    if pytesseract is None:
        return False
    cmd = pytesseract.pytesseract.tesseract_cmd or "tesseract"
    try:
        kwargs = {"creationflags": runtime.subprocess.CREATE_NO_WINDOW} if runtime.sys.platform.startswith("win") else {}
        runtime.subprocess.run([cmd, "--version"], capture_output=True, timeout=2, **kwargs)
        return True
    except Exception:
        return False


def rapid_ready() -> bool:
    return runtime.importlib.util.find_spec("rapidocr_onnxruntime") is not None


def pick_engine() -> str:
    """Вибір рушія; результат кешується на хвилину (перевірка Tesseract запускає процес)."""
    key = (runtime.ocr_settings()["engine"], runtime.ocr_settings()["tesseract_cmd"])
    if runtime._engine_cache["key"] == key and runtime.time.time() - runtime._engine_cache["t"] < 60:
        return runtime._engine_cache["val"]
    val = runtime._pick_engine_uncached()
    runtime._engine_cache.update(key=key, val=val, t=runtime.time.time())
    return val


def _pick_engine_uncached() -> str:
    eng = runtime.ocr_settings()["engine"]
    if eng == "tesseract" and runtime.tesseract_ready():
        return "tesseract"
    if eng == "rapidocr" and runtime.rapid_ready():
        return "rapidocr"
    if eng == "auto":
        if runtime.tesseract_ready():
            return "tesseract"
        if runtime.rapid_ready():
            return "rapidocr"
    raise runtime.OcrError("Не знайдено OCR-рушій. Встанови: pip install rapidocr-onnxruntime "
                   "(або Tesseract + pytesseract).")


def ocr_tesseract(img, scale: float):
    pytesseract = runtime._configure_tesseract_cmd()
    if pytesseract is None:
        raise runtime.OcrError("pytesseract не встановлено")
    with ocr_slot():
        settings = runtime.ocr_settings()
        work, sx, sy = fit_image(img, settings)
        payload = io.BytesIO()
        work.convert("L").save(payload, format="PNG")
        # pytesseract has no per-call environment argument. Launch its same TSV
        # command directly so concurrent jobs never mutate os.environ globally.
        environment = os.environ.copy()
        environment["OMP_THREAD_LIMIT"] = str(cpu_threads(settings))
        command = pytesseract.pytesseract.tesseract_cmd or "tesseract"
        flags = ({"creationflags": runtime.subprocess.CREATE_NO_WINDOW}
                 if runtime.sys.platform.startswith("win") else {})
        timeout = bounded_number(settings, "tesseract_timeout", 8, 2, 30)
        try:
            result = runtime.subprocess.run(
                [command, "stdin", "stdout", "-l", "eng", "--psm", "6", "tsv"],
                input=payload.getvalue(), capture_output=True, timeout=timeout,
                env=environment, **flags)
        except runtime.subprocess.TimeoutExpired as error:
            raise runtime.OcrError(f"Tesseract перевищив тайм-аут {timeout:g} с") from error
        if result.returncode:
            detail = result.stderr.decode("utf-8", "replace").strip()[-300:]
            raise runtime.OcrError(f"Tesseract: {detail or 'помилка запуску'}")
        check_cancelled()
        out = []
        rows = csv.DictReader(io.StringIO(result.stdout.decode("utf-8", "replace")),
                              delimiter="\t", quoting=csv.QUOTE_NONE)
        for row in rows:
            text = (row.get("text") or "").strip()
            if not text:
                continue
            try:
                if float(row["conf"]) < 15:
                    continue
                x, y, w, h = (float(row[key]) for key in ("left", "top", "width", "height"))
                line = tuple(int(row[key]) for key in ("block_num", "par_num", "line_num"))
            except (KeyError, TypeError, ValueError):
                continue
            out.append(runtime.W(text, x / (scale * sx), y / (scale * sy),
                                 (x + w) / (scale * sx), (y + h) / (scale * sy), line))
        return out


def _char_w(ch: str) -> float:
    if ch in runtime._NARROW:
        return 0.45
    if ch in runtime._WIDE:
        return 1.5
    return 1.15 if ch.isupper() else 1.0


def split_line_words(text, x0, y0, x1, y1, line_id):
    """Ділить рядок OCR на слова пропорційно ширині символів."""
    tokens = list(runtime.re.finditer(r"\S+", text))
    if not tokens:
        return []
    cum = [0.0]
    for ch in text:
        cum.append(cum[-1] + runtime._char_w(ch))
    k = (x1 - x0) / (cum[-1] or 1)
    return [runtime.W(m.group(), x0 + cum[m.start()] * k, y0, x0 + cum[m.end()] * k, y1, line_id)
            for m in tokens]


def _speed_up_rapid(eng) -> None:
    """Use the supported detector setting, not its recreated preprocess object."""
    eng.text_det.limit_type = "max"
    eng.max_side_len = max_side(runtime.ocr_settings())


def _rapid_engine():
    global _rapid_settings
    settings = runtime.ocr_settings()
    key = (cpu_threads(settings), max_side(settings))
    with ocr_slot(), runtime._rapid_lock:
        if runtime._rapid_run is None or _rapid_settings != key:
            try:
                eng = create_rapid_engine(*key)
                runtime._speed_up_rapid(eng)

                def run(arr):
                    # Validated API of the pinned backend; do not repeat a
                    # failed native invocation through a speculative fallback.
                    res, _ = eng(arr, use_cls=False, text_score=0.3, box_thresh=0.3,
                                 return_word_box=True)
                    # Keep CTC character positions. A whole-line rectangle and
                    # guessed letter widths cannot reliably locate a word.
                    return res or []
            except (ImportError, RuntimeError) as error:
                raise runtime.OcrError(str(error) or
                    "Встанови rapidocr-onnxruntime==1.4.4 для обмеження CPU") from error
            runtime._rapid_run = run
            _rapid_settings = key
        return runtime._rapid_run


def _line_gaps(img, x0, y0, x1, y1, min_gap_frac=0.2):
    """Visible word-size whitespace, in image coordinates; no word-count guess."""
    try:
        import numpy as np
    except ImportError:
        return None
    X0, Y0 = max(int(x0), 0), max(int(y0), 0)
    X1, Y1 = min(int(x1) + 1, img.width), min(int(y1) + 1, img.height)
    if X1 - X0 < 4 or Y1 - Y0 < 4:
        return None
    arr = np.asarray(img.crop((X0, Y0, X1, Y1)).convert("L"), dtype=np.float32)
    # «чорнило» стовпця = розкид яскравості (макс − мін): не залежить від кольору фону і
    # не ламається, коли жирний текст займає понад половину рамки (медіана тоді
    # стала б кольором самого тексту й усе інвертувалось)
    ink = arr.max(axis=0) - arr.min(axis=0)
    if ink.max() < 8:  # майже немає контрасту — не довіряємо
        return None
    is_bg = ink <= max(ink.max() * 0.12, 2.0)
    cols = np.flatnonzero(~is_bg)
    if len(cols) == 0:
        return None
    first, last = int(cols[0]), int(cols[-1])
    min_gap = max(2, int((Y1 - Y0) * min_gap_frac))
    runs, i = [], first
    while i <= last:
        if is_bg[i]:
            j = i
            while j <= last and is_bg[j]:
                j += 1
            if j - i >= min_gap:
                runs.append((i, j))
            i = j
        else:
            i += 1
    return X0 + first, X0 + last + 1, [(X0 + a, X0 + b) for a, b in runs]


def _gap_segments(img, n, x0, y0, x1, y1, min_gap_frac=0.2):
    """Use image gaps only when they agree with the recognized word count."""
    if n < 2:
        return None
    found = _line_gaps(img, x0, y0, x1, y1, min_gap_frac)
    if found is None:
        return None
    first, last, runs = found
    if len(runs) != n - 1:
        # Choosing just the widest gaps silently shifts labels when OCR omits
        # a word/space. Ambiguous geometry must not select a neighbouring word.
        return None
    bounds, start = [], first
    for a, b in runs:
        bounds.append((start, a))
        start = b
    bounds.append((start, last))
    return bounds


def _ctc_words(img, record, line_id):
    """Locate tokens using recognizer positions, including OCR-dropped spaces."""
    if len(record) < 5:
        return None
    box, text, _score, boxes, characters = record[:5]
    if len(boxes) != len(characters) or "".join(characters) != text:
        return None
    entries = []
    for char, points in zip(characters, boxes):
        if not points:
            return None
        xs, ys = [point[0] for point in points], [point[1] for point in points]
        entries.append((char, min(xs), min(ys), max(xs), max(ys)))
    if not entries:
        return []
    xs, ys = [point[0] for point in box], [point[1] for point in box]
    found = _line_gaps(img, min(xs), min(ys), max(xs), max(ys))
    gaps = found[2] if found else []
    visible = [entry for entry in entries if not entry[0].isspace()]
    advances = [(right[1] + right[3] - left[1] - left[3]) / 2
                for left, right in zip(visible, visible[1:])]
    positive = sorted(value for value in advances if value > 0)
    typical = positive[len(positive) // 2] if positive else 1
    groups, current = [], []
    for entry in entries:
        if entry[0].isspace():
            if current:
                groups.append(current)
                current = []
            continue
        if current:
            previous = current[-1]
            left = (previous[1] + previous[3]) / 2
            right = (entry[1] + entry[3]) / 2
            # A missing OCR space needs both physical whitespace and a larger
            # recognizer advance. Letter kerning alone cannot create a break.
            if right - left >= 1.35 * typical and any(
                    left < (a + b) / 2 < right for a, b in gaps):
                groups.append(current)
                current = []
        current.append(entry)
    if current:
        groups.append(current)
    return [runtime.W("".join(entry[0] for entry in group),
                      min(entry[1] for entry in group), min(entry[2] for entry in group),
                      max(entry[3] for entry in group), max(entry[4] for entry in group), line_id)
            for group in groups]


def ocr_rapid(img, scale: float):
    with ocr_slot():
        import numpy as np
        work, sx, sy = fit_image(img, runtime.ocr_settings())
        arr = np.ascontiguousarray(np.array(work.convert("RGB"))[:, :, ::-1])  # RGB -> BGR
        recognized = runtime._rapid_engine()(arr)
        check_cancelled()
        out = []
        for i, record in enumerate(recognized):
            box, text, _score = record[:3]
            positioned = _ctc_words(work, record, i)
            if positioned is not None:
                out += [word._replace(x0=word.x0 / (scale * sx), x1=word.x1 / (scale * sx),
                                      y0=word.y0 / (scale * sy), y1=word.y1 / (scale * sy))
                        for word in positioned]
                continue
            xs, ys = [p[0] for p in box], [p[1] for p in box]
            tokens = list(runtime.re.finditer(r"\S+", text))
            segs = runtime._gap_segments(work, len(tokens), min(xs), min(ys), max(xs), max(ys))
            if segs is not None:
                out += [runtime.W(m.group(), a / (scale * sx), min(ys) / (scale * sy),
                                  b / (scale * sx), max(ys) / (scale * sy), i)
                        for m, (a, b) in zip(tokens, segs)]
            elif len(tokens) == 1:
                out.append(runtime.W(text, min(xs) / (scale * sx), min(ys) / (scale * sy),
                                     max(xs) / (scale * sx), max(ys) / (scale * sy), i))
            # Multiword lines without valid geometry are deliberately omitted;
            # proportional widths can highlight a different word from the text.
        return out


def pick_word(words, cx, cy, tol):
    """Select one containing box; whitespace and overlapping boxes are ambiguous.

    The legacy tol parameter remains accepted for integrations. It no longer
    turns a nearby word into a purported word under the cursor.
    """
    inside = [word for word in words if word.x0 <= cx < word.x1 and word.y0 <= cy < word.y1]
    return inside[0] if len(inside) == 1 else None


def clean_word(raw: str):
    """Повертає (слово, частка_початку, частка_кінця) без пунктуації навколо."""
    t = raw.replace("’", "'")
    lead = len(t) - len(t.lstrip(runtime.STRIP_CHARS))
    trail = len(t) - len(t.rstrip(runtime.STRIP_CHARS))
    core = t.strip(runtime.STRIP_CHARS)
    if not runtime.WORD_RE.fullmatch(core):
        m = runtime.re.search(r"[A-Za-z][A-Za-z'-]*", core)
        core = m.group(0).strip("'-") if m else ""
    n = max(len(t), 1)
    return core, lead / n, trail / n


def _grab(x0, y0, x1, y1, frozen=None):
    """Знімок прямокутника екрана (обрізаний по межах усіх моніторів). Якщо передано
    frozen=(img, ox, oy) — уже готовий «стоп-кадр» (напр. з RegionSelector) — вирізає
    з нього, без нового звернення до екрана. Так виділена рамкою підказка, що зникає
    при русі миші (тултіп у грі), лишається на застиглому зображенні."""
    if frozen is not None:
        fimg, fox, foy = frozen
        left, top = max(fox, int(x0)), max(foy, int(y0))
        right = min(fox + fimg.width, int(x1))
        bottom = min(foy + fimg.height, int(y1))
        if right - left < 4 or bottom - top < 4:
            raise runtime.OcrError("Область надто мала або поза межами знімка")
        img = fimg.crop((left - fox, top - foy, right - fox, bottom - foy))
        return img, left, top, right, bottom, 1.0, 1.0
    try:
        import mss
        from PIL import Image
    except ImportError:
        raise runtime.OcrError("Встанови бібліотеки: pip install mss pillow")
    try:
        with mss.mss() as sct:
            vs = sct.monitors[0]
            left, top = max(vs["left"], int(x0)), max(vs["top"], int(y0))
            right = min(vs["left"] + vs["width"], int(x1))
            bottom = min(vs["top"] + vs["height"], int(y1))
            if right - left < 4 or bottom - top < 4:
                raise runtime.OcrError("Область надто мала або поза екраном")
            shot = sct.grab({"left": left, "top": top,
                             "width": right - left, "height": bottom - top})
    except runtime.OcrError:
        raise
    except Exception as e:
        raise runtime.OcrError(f"Не вдалося зробити знімок екрана: {e}")
    img = Image.frombytes("RGB", shot.size, shot.bgra, "raw", "BGRX")
    return (img, left, top, right, bottom,
            shot.width / (right - left), shot.height / (bottom - top))


def _attempts(engine, height_px=None):
    """Спроби OCR по черзі (назва, збільшення, інвертувати) — далі йдемо, лише якщо попередня не знайшла."""
    if engine == "tesseract":
        up = (runtime.clamp(runtime.ocr_settings()["upscale"], 1.0, 4.0) if height_px is None
              else runtime.clamp(48 / max(height_px, 1), 1.0, 4.0))
        return [("звичайний", up, False), ("інвертований", up, True)]
    return [("звичайний", 1.0, False), ("інвертований", 1.0, True), ("збільшений", 2.0, False)]


def _run_ocr(engine, img, up, invert):
    from PIL import ImageOps
    check_cancelled()
    # Preserve narrow subtitle text: tile a very wide strip rather than shrink
    # its letters below their original height. Full frames use the size cap.
    if img.width > max_side(runtime.ocr_settings()) and img.height <= 160:
        return runtime._ocr_wide(img, engine, invert)
    with ocr_slot():
        work, sx, sy = fit_image(img, runtime.ocr_settings(), up)
        if invert:
            work = ImageOps.invert(work.convert("RGB"))
        words = (runtime.ocr_tesseract if engine == "tesseract" else runtime.ocr_rapid)(work, 1.0)
        return [word._replace(x0=word.x0 / sx, x1=word.x1 / sx,
                              y0=word.y0 / sy, y1=word.y1 / sy) for word in words]


def _find_word_gap(img, box, min_gap_frac=0.26):
    """Шукає в межах box найширшу вертикальну прогалину — можливий пробіл, який OCR
    об'єднав із сусіднім словом. Повертає x-координату розриву (в межах img) або None."""
    x0, y0, x1, y1 = (int(v) for v in box)
    x0, y0 = max(x0, 0), max(y0, 0)
    x1, y1 = min(x1, img.width), min(y1, img.height)
    if x1 - x0 < 14 or y1 - y0 < 5:
        return None
    try:
        import numpy as np
    except ImportError:
        return None
    arr = np.asarray(img.crop((x0, y0, x1, y1)).convert("L"), dtype=np.float32)
    ink = arr.max(axis=0) - arr.min(axis=0)  # розкид яскравості по стовпцях (див. _gap_segments)
    if ink.max() < 8:  # надто мало контрасту — не варто довіряти
        return None
    is_bg = ink <= max(ink.max() * 0.12, 2.0)
    h, n = y1 - y0, len(is_bg)
    min_gap = max(3, int(h * min_gap_frac))
    runs, i = [], 0
    while i < n:
        if is_bg[i]:
            j = i
            while j < n and is_bg[j]:
                j += 1
            if j - i >= min_gap and i > 2 and j < n - 2:
                runs.append((i, j))
            i = j
        else:
            i += 1
    if not runs:
        return None
    a, b = max(runs, key=lambda ab: ab[1] - ab[0])
    return x0 + (a + b) / 2


def _reocr_crop(img, box, engine, point=None):
    """Вирізає фрагмент зображення і розпізнає його окремо — для уточнення однієї
    половини слова, яке OCR помилково злив із сусіднім."""
    pad = 4
    x0, y0, x1, y1 = (int(v) for v in box)
    x0, y0 = max(x0 - pad, 0), max(y0 - pad, 0)
    x1, y1 = min(x1 + pad, img.width), min(y1 + pad, img.height)
    if x1 - x0 < 6 or y1 - y0 < 6:
        return None
    crop = img.crop((x0, y0, x1, y1))
    try:
        words = runtime._run_ocr(engine, crop, 3.0, False)
    except LookupCancelled:
        raise
    except Exception:
        return None
    if point is not None:
        chosen = runtime.pick_word(words, point[0] - x0, point[1] - y0, tol=0)
        if chosen is None:
            return None
        text = chosen.text
    elif len(words) == 1:
        text = words[0].text
    else:
        # Joining a crop's words and taking the first one labels the whole crop
        # with that word, even when the pointer is over its last word.
        return None
    if len(runtime.re.findall(r"\S+", text)) != 1:
        return None
    return runtime.clean_word(text)[0] or None


def _split_merged_word(img, hit, cx, engine):
    """Якщо розпізнане «слово» без пробілу насправді два злиті слова (видно проміжок
    на зображенні), повертає уточнений hit лише з тим словом, де курсор.
    None — уточнення не потрібне; False — неоднозначну рамку слід відхилити."""
    if not runtime.ocr_settings()["split_merged_words"] or len(hit.text) < 5:
        return None
    found = _line_gaps(img, hit.x0, hit.y0, hit.x1, hit.y1, min_gap_frac=0.26)
    if found is None or not found[2]:
        return None
    first, last, gaps = found
    left, right = first, last
    for start, end in gaps:
        if start <= cx < end:
            return False  # Ambiguous: whitespace must not keep the broad box.
        if end <= cx:
            left = end
        elif start > cx:
            right = start
            break
    side = (left, hit.y0, right, hit.y1)
    refined = runtime._reocr_crop(img, side, engine, point=(cx, (hit.y0 + hit.y1) / 2))
    if not refined:
        return False  # The broad box contains multiple spans; do not guess.
    if refined.lower() == hit.text.lower():
        return None
    runtime.log(f"OCR: «{hit.text}» виглядає як злиті слова, уточнено до «{refined}»")
    return hit._replace(text=refined, x0=side[0], x1=side[2])


def _find_word_at(x, y, debug, wide, frozen=None):
    check_cancelled()
    runtime.LAST_OCR["count"] = 0
    engine = runtime.pick_engine()
    O = runtime.ocr_settings()
    rw = int(runtime.clamp(O["region_w"], 200, 2000) * (1.8 if wide else 1.0))
    rh = int(runtime.clamp(O["region_h"], 40, 600))
    img, left, top, right, bottom, sx, sy = runtime._grab(x - rw / 2, y - rh / 2, x + rw / 2, y + rh / 2, frozen)
    cx, cy = (x - left) * sx, (y - top) * sy
    if debug is not None:
        debug.update(img=img, cursor=(cx, cy), engine=engine, variants=[],
                     region=(left, top, right, bottom), shot=img.size)
    hit, hit_words = None, []
    try:
        for name, up, invert in runtime._attempts(engine):
            check_cancelled()
            words = runtime._run_ocr(engine, img, up, invert)
            runtime.LAST_OCR["count"] = max(runtime.LAST_OCR["count"], len(words))
            if debug is not None:
                debug["variants"].append((name, words))
            if hit is None:
                cand = [w for w in words if runtime.re.search(r"[A-Za-z]", w.text)]
                found = runtime.pick_word(cand, cx, cy, tol=0)
                if found:
                    hit, hit_words = found, words
            if hit is not None and debug is None:
                break
    except (runtime.OcrError, LookupCancelled):
        raise
    except Exception as e:
        runtime.log_exc()
        raise runtime.OcrError(f"Помилка OCR: {type(e).__name__}: {e}")
    if hit is None:
        return None

    line_words = next((ln for ln in runtime.cluster_lines(hit_words) if hit in ln), [hit])
    refined = runtime._split_merged_word(img, hit, cx, engine)
    if refined is False:
        return None
    if refined is not None:
        hit = refined
    word, lead, trail = runtime.clean_word(hit.text)
    core = hit.text.replace("’", "'").strip(runtime.STRIP_CHARS)
    if not word or core.lower() != word.lower():
        # clean_word's permissive text extraction is useful for diagnostics,
        # but its first substring is not a valid label for a whole-line box.
        return None
    wd = hit.x1 - hit.x0
    x0, x1 = hit.x0 + wd * lead, hit.x1 - wd * trail
    if not (x0 <= cx < x1 and hit.y0 <= cy < hit.y1):
        return None
    box = (runtime.math.floor(left + x0 / sx), runtime.math.floor(top + hit.y0 / sy),
           runtime.math.ceil(left + x1 / sx), runtime.math.ceil(top + hit.y1 / sy))
    return {
        "word": word,
        "box": box,
        "line_text": " ".join(w.text for w in line_words),
    }


def find_word_at(x: int, y: int, debug=None, wide=False, frozen=None):
    """Знімок екрана навколо (x, y) -> OCR -> слово під курсором.
    debug (dict) — збирає знімок і результати всіх спроб; wide=True — ширша область (для рядка);
    frozen=(img, ox, oy) — не знімати новий скріншот, а взяти вже готовий «стоп-кадр»
    (напр. якщо в грі підказка (тултіп) зникає при русі миші — її вже «заморожено»)."""
    t0 = runtime.time.time()
    try:
        return runtime._find_word_at(x, y, debug, wide, frozen)
    finally:
        runtime.LAST_OCR["time"] = runtime.time.time() - t0


def cluster_lines(words):
    """Групує слова у рядки за фактичним вертикальним розташуванням (перекриттям
    по Y центру й висоті), а НЕ за 'id рядка' з самого OCR. RapidOCR часто дає
    кожному виявленому текстовому фрагменту власний id, навіть якщо він візуально
    на одному рядку з сусідніми (напр. "Slowdive", "·", "Sleep (2022 Remastered)")
    — тоді групування за id розбиває один рядок на кілька й порядок слів ламається.
    Повертає список рядків (згори вниз), кожен — список слів (зліва направо)."""
    if not words:
        return []
    items = sorted(words, key=lambda w: (w.y0 + w.y1) / 2)
    lines = []
    for w in items:
        wc = (w.y0 + w.y1) / 2
        wh = max(w.y1 - w.y0, 1)
        placed = False
        for line in lines:
            lc = sum((x.y0 + x.y1) / 2 for x in line) / len(line)
            lh = sum(x.y1 - x.y0 for x in line) / len(line)
            if abs(wc - lc) <= max(lh, wh) * 0.55:  # достатньо близько по вертикалі -> той самий рядок
                line.append(w)
                placed = True
                break
        if not placed:
            lines.append([w])
    lines.sort(key=lambda line: min(x.y0 for x in line))
    return [sorted(line, key=lambda w: w.x0) for line in lines]


def ocr_region(x0, y0, x1, y1, debug=None, frozen=None):
    """OCR виділеної рамки. Повертає слова в екранних координатах у порядку читання.
    frozen=(img, ox, oy) — брати дані з уже готового «стоп-кадру», а не з нового знімка."""
    check_cancelled()
    runtime.LAST_OCR["count"] = 0
    engine = runtime.pick_engine()
    m = 6  # невеликий запас навколо рамки — не відрізати краї літер
    img, L, T, R, B, sx, sy = runtime._grab(x0 - m, y0 - m, x1 + m, y1 + m, frozen)
    sel = ((x0 - L) * sx, (y0 - T) * sy, (x1 - L) * sx, (y1 - T) * sy)
    tol = 3 * max(sx, 1.0)
    inside = []
    try:
        for name, up, invert in runtime._attempts(engine, (y1 - y0) * sy):
            check_cancelled()
            words = runtime._run_ocr(engine, img, up, invert)
            runtime.LAST_OCR["count"] = max(runtime.LAST_OCR["count"], len(words))
            if debug is not None:
                debug.setdefault("variants", []).append((name, words))
            inside = [w for w in words
                      if sel[0] - tol <= (w.x0 + w.x1) / 2 <= sel[2] + tol
                      and sel[1] - tol <= (w.y0 + w.y1) / 2 <= sel[3] + tol]
            if inside:
                break
    except (runtime.OcrError, LookupCancelled):
        raise
    except Exception as e:
        runtime.log_exc()
        raise runtime.OcrError(f"Помилка OCR: {type(e).__name__}: {e}")
    if not inside:
        return []
    if len(inside) == 1:
        merged = inside[0]
        refined = runtime._split_merged_word(img, merged, (sel[0] + sel[2]) / 2, engine)
        if refined is False:
            return []
        if refined is not None:
            inside = [refined]
    ordered = [w for line in runtime.cluster_lines(inside) for w in line]
    return [runtime.W(w.text, L + w.x0 / sx, T + w.y0 / sy, L + w.x1 / sx, T + w.y1 / sy, w.line)
            for w in ordered]


def _ends_sentence(tok: str) -> bool:
    """Токен завершує речення: .!? (з можливими лапками/дужками після), але не «Dr.»
    і не три крапки (пауза в субтитрах — речення триває)."""
    t = tok.rstrip("\"'”’»)]}")
    if not t or t[-1] not in ".!?" or t.endswith(("...", "…")):
        return False
    return not (t.endswith(".") and t[:-1].lower() in runtime._ABBR)


def _sentence_around(tokens: list, idx: int, max_tokens: int = 40) -> str:
    """Речення, що містить токен idx. tokens — список рядків."""
    start = idx
    while start > 0 and idx - start < max_tokens and not runtime._ends_sentence(tokens[start - 1]):
        start -= 1
    end = idx
    while end < len(tokens) - 1 and end - idx < max_tokens and not runtime._ends_sentence(tokens[end]):
        end += 1
    seg = tokens[start:end + 1]
    if len(seg) > 1 and seg[0].endswith(":") and len(seg[0]) <= 16:  # «Evelyn:» — не частина речення
        seg = seg[1:]
    return " ".join(seg)


def _ocr_wide(img, engine, invert=False):
    """OCR широкої смуги шматками по ≤900 px із перекриттям: RapidOCR зменшує вхід до ~960 px,
    тож по всій ширині дрібний текст псувався б. Слова з перекриття беруться лише з
    того шматка, де вони в «серцевині» (обрізані на краю відкидаються)."""
    check_cancelled()
    from PIL import ImageOps
    work = ImageOps.invert(img.convert("RGB")) if invert else img
    run = runtime.ocr_tesseract if engine == "tesseract" else runtime.ocr_rapid
    total = work.width
    chunk = min(900 if engine == "rapidocr" else 1600,
                max_side(runtime.ocr_settings()))
    if total <= chunk:
        return run(work, 1.0)
    overlap = 120
    out = []
    for i, st in enumerate(range(0, max(1, total - overlap), chunk - overlap)):
        check_cancelled()
        en = min(total, st + chunk)
        if en - st < 60:
            continue
        lo = st + (overlap // 2 if i > 0 else 0)
        hi = en - (overlap // 2 if en < total else 0)
        for w in run(work.crop((st, 0, en, work.height)), 1.0):
            if lo <= st + (w.x0 + w.x1) / 2 < hi:
                out.append(w._replace(x0=w.x0 + st, x1=w.x1 + st))
    return out


def _pick_anchor(words: list, hit: dict):
    """Слово зі смуги, що відповідає знайденому слову (за текстом і близькістю)."""
    bx0, by0, bx1, by1 = hit["box"]
    cx, cy = (bx0 + bx1) / 2, (by0 + by1) / 2
    target = hit["word"].lower()
    best, best_d = None, 1e9
    for w in words:
        d = runtime.math.hypot((w.x0 + w.x1) / 2 - cx, (w.y0 + w.y1) / 2 - cy)
        if runtime.clean_word(w.text)[0].lower() == target and d < best_d and d <= max(60, 2 * (by1 - by0)):
            best, best_d = w, d
    if best:
        return best
    inside = [w for w in words if w.x0 <= cx <= w.x1 and w.y0 <= cy <= w.y1]
    return inside[0] if inside else None


def find_sentence(hit: dict, frozen=None) -> str:
    """Повне речення, у якому стоїть знайдене слово. Знімає смугу екрана навколо слова на
    повну ширину (±1100 px) і висоту ~2 рядки вгору/вниз, розпізнає її, збирає
    підписи, перенесені на кілька рядків, і обрізає по межах речення. Порожній
    рядок — якщо надійно визначити не вдалось (тоді лишається короткий рядок)."""
    check_cancelled()
    frame_words = hit.get("_frame_words")
    if frame_words is not None:
        # The keyboard/hover selector already recognized this exact frozen
        # frame. Reuse its screen coordinates instead of repeating inference.
        bx0, by0, bx1, by1 = hit["box"]
        height = max(10.0, by1 - by0)
        centre = (by0 + by1) / 2
        nearby = [word for word in frame_words
                  if bx0 - 1100 <= (word.x0 + word.x1) / 2 <= bx1 + 1100
                  and centre - 2.3 * height <= (word.y0 + word.y1) / 2 <= centre + 2.3 * height]
        reused = _sentence_from_words(nearby, hit)
        if reused is not None:
            return reused
    engine = runtime.pick_engine()
    bx0, by0, bx1, by1 = hit["box"]
    h = max(10.0, by1 - by0)
    cy = (by0 + by1) / 2
    img, left, top, right, bottom, sx, sy = runtime._grab(bx0 - 1100, cy - 2.3 * h, bx1 + 1100, cy + 2.3 * h, frozen)
    anchor, screen = None, []
    for invert in (False, True):  # світлий текст на темному і навпаки
        check_cancelled()
        words = [w for w in runtime._ocr_wide(img, engine, invert) if runtime.re.search(r"[A-Za-z0-9]", w.text)]
        screen = [w._replace(x0=left + w.x0 / sx, x1=left + w.x1 / sx,
                             y0=top + w.y0 / sy, y1=top + w.y1 / sy) for w in words]
        anchor = runtime._pick_anchor(screen, hit)
        if anchor is not None:
            break
    if anchor is None:
        return ""
    return _sentence_from_words(screen, hit) or ""


def _sentence_from_words(screen, hit):
    """None means missing anchor; an empty sentence needs no repeated OCR."""
    check_cancelled()
    anchor = runtime._pick_anchor(screen, hit)
    if anchor is None:
        return None
    lines = runtime.cluster_lines(screen)
    ai = next(i for i, ln in enumerate(lines) if anchor in ln)

    def height(ln): return sum(w.y1 - w.y0 for w in ln) / len(ln)
    def centre(ln): return sum((w.y0 + w.y1) / 2 for w in ln) / len(ln)
    def near(a, b): return abs(centre(a) - centre(b)) <= 1.9 * height(a) and 0.6 <= height(b) / height(a) <= 1.7
    def starts_lower(ln): return ln[0].text[:1].islower()
    lo = hi = ai
    # рядок продовжує речення, лише якщо попередній не закінчився крапкою, а цей починається
    # з малої літери — так пункти меню («RESUME GAME / OPTIONS») не склеюються в «речення»
    while lo > 0 and near(lines[lo], lines[lo - 1]) and starts_lower(lines[lo]) \
            and not runtime._ends_sentence(lines[lo - 1][-1].text):
        lo -= 1
    while hi < len(lines) - 1 and near(lines[hi], lines[hi + 1]) and starts_lower(lines[hi + 1]) \
            and not runtime._ends_sentence(lines[hi][-1].text):
        hi += 1
    ordered = [w for ln in lines[lo:hi + 1] for w in ln]
    idx = next(i for i, w in enumerate(ordered) if w is anchor)
    sentence = runtime._sentence_around([w.text for w in ordered], idx)
    return sentence if len(sentence.split()) >= 2 else ""
