@echo off
setlocal DisableDelayedExpansion
pushd "%~dp0"
if errorlevel 1 exit /b 1
if not exist ".venv\Scripts\python.exe" (
    call install.bat
    if errorlevel 1 goto fail
)
".venv\Scripts\python.exe" word_lookup.py
if errorlevel 1 goto fail
popd
exit /b 0

:fail
echo Word Lookup could not start. Run install.bat to repair dependencies.
if not defined CI pause
popd
exit /b 1
