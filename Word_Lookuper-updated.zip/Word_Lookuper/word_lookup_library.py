"""Saved-word library editor, review and export views."""

from __future__ import annotations

runtime = None


def configure(application):
    global runtime
    runtime = application


class LibraryViewMixin:
    def refresh_saved_count(self):
        n = len(runtime.load_saved_words())
        if hasattr(self, "saved_btn"):
            self.saved_btn.config(text=f"⭐ Збережені слова ({n})")
        if getattr(self, "saved_win", None) is not None:
            self._render_saved_list()

    def open_saved_words(self):
        if getattr(self, "saved_win", None) is not None:
            self.saved_win.deiconify()
            self.saved_win.lift()
            self._render_saved_list()
            return
        win = self.saved_win = runtime.tk.Toplevel(self.root)
        win.title("Бібліотека — Word Lookup")
        win.configure(bg="#111318")
        win.geometry("1200x740")
        win.minsize(980, 540)
        win.protocol("WM_DELETE_WINDOW", self._hide_saved_window)
        self._editor_word = None
        self._editor_dirty = False
        self._loading_editor = False
        self.saved_query = runtime.tk.StringVar()
        self.saved_order = runtime.tk.StringVar(value="Спочатку нові")
        self.saved_state_filter = runtime.tk.StringVar(value="Усі")
        self.saved_due_only = runtime.tk.BooleanVar(value=False)
        panes = runtime.ttk.Panedwindow(win, orient="horizontal")
        panes.pack(fill="both", expand=True)
        left = runtime.ttk.Frame(panes, style="Sidebar.TFrame", padding=(20, 22))
        panes.add(left, weight=2)
        self.library_title = runtime.tk.StringVar()
        runtime.ttk.Label(left, textvariable=self.library_title, style="Sidebar.TLabel",
                  foreground="#f1f1f5", font=(runtime.FONT, 18, "bold")).pack(anchor="w", pady=(0, 18))
        search = runtime.ttk.Entry(left, textvariable=self.saved_query, width=36)
        search.pack(fill="x", pady=(0, 5))
        runtime.ttk.Label(left, text="Пошук за словом, перекладом, грою", style="Sidebar.TLabel",
                  font=(runtime.FONT, 9)).pack(anchor="w", pady=(0, 12))
        filters = runtime.ttk.Frame(left, style="Sidebar.TFrame")
        filters.pack(fill="x", pady=(0, 4))
        for label in runtime.STATUS_LABELS:
            runtime.ttk.Radiobutton(filters, text=label, value=label, variable=self.saved_state_filter,
                            style="Filter.TRadiobutton").pack(side="left")
        runtime.ttk.Checkbutton(left, text="Час повторити", variable=self.saved_due_only).pack(anchor="w", pady=(3, 12))
        list_area = runtime.ttk.Frame(left, style="Sidebar.TFrame")
        list_area.pack(fill="both", expand=True)
        self.saved_tree = runtime.ttk.Treeview(list_area, columns=("check", "word", "translation", "state", "source"),
                                       displaycolumns=("check", "word", "translation", "source"),
                                       show="headings", selectmode="browse", height=5)
        for col, label, width in (("check", "✓", 24), ("word", "Слово", 115),
                                  ("translation", "Переклад", 120), ("state", "Стан", 60),
                                  ("source", "Гра", 90)):
            self.saved_tree.heading(col, text=label)
            self.saved_tree.column(col, width=width, minwidth=24, stretch=col != "check")
        bar = runtime.ttk.Scrollbar(list_area, orient="vertical", command=self.saved_tree.yview)
        self.saved_tree.configure(yscrollcommand=bar.set)
        bar.pack(side="right", fill="y")
        self.saved_tree.pack(fill="both", expand=True)
        self.saved_tree.bind("<Button-1>", self._saved_tree_click)
        self.saved_tree.bind("<<TreeviewSelect>>", self._saved_tree_select)
        self.saved_tree.bind("<Double-1>", lambda _e: self._open_selected_popup())
        self.saved_tree.bind("<Return>", lambda _e: self._open_selected_popup())
        selection = runtime.ttk.Frame(left, style="Sidebar.TFrame")
        selection.pack(fill="x", pady=(12, 6))
        runtime.ttk.Button(selection, text="Вибрати знайдені", command=lambda: self.select_all_saved(True)).pack(side="left")
        runtime.ttk.Button(selection, text="Зняти", command=lambda: self.select_all_saved(False)).pack(side="left", padx=5)
        self.saved_selected_var = runtime.tk.StringVar()
        runtime.ttk.Label(left, textvariable=self.saved_selected_var, style="Sidebar.TLabel").pack(anchor="w", pady=4)
        runtime.ttk.Combobox(left, state="readonly", textvariable=self.saved_order,
                     values=["Спочатку нові", "Спочатку старі", "За абеткою"]).pack(fill="x", pady=4)
        right = runtime.ttk.Frame(panes, padding=(24, 22))
        panes.add(right, weight=3)
        tools = runtime.ttk.Frame(right)
        tools.pack(fill="x", pady=(0, 14))
        runtime.ttk.Button(tools, text="Повторити слова", command=self.review_saved_words).pack(side="left")
        self.anki_sync_btn = runtime.ttk.Button(tools, text="Передати в Anki", style="Accent.TButton", command=self.sync_saved_to_anki)
        self.anki_sync_btn.pack(side="right")
        detail = runtime.ScrolledPanel(right, bg="#111318")
        detail.pack(fill="both", expand=True)
        self.saved_list_frame = detail.content
        export = runtime.ttk.Frame(right)
        export.pack(fill="x", pady=(14, 0))
        runtime.ttk.Label(export, text="Колода").pack(side="left")
        runtime.ttk.Entry(export, width=18, textvariable=self._var(runtime.tk.StringVar, ("anki", "deck"))).pack(side="left", padx=6)
        runtime.ttk.Button(export, text="Експорт .txt", command=self.export_anki_selected).pack(side="right")
        runtime.ttk.Button(export, text="Експорт .apkg", command=self.export_anki_apkg_selected).pack(side="right", padx=5)
        self.anki_sync_status = runtime.tk.StringVar(value="Для передавання відкрий Anki з AnkiConnect на цьому ПК.")
        runtime.ttk.Label(right, textvariable=self.anki_sync_status, foreground="#a2a8b8", wraplength=540).pack(anchor="w", pady=(8, 0))
        for var in (self.saved_query, self.saved_order, self.saved_state_filter, self.saved_due_only):
            var.trace_add("write", lambda *_: self._render_saved_list())
        win.bind("<Control-f>", lambda _e: search.focus_set())
        win.bind("<Escape>", lambda _e: self._hide_saved_window())
        win.bind("<Control-s>", lambda _e: self.save_saved_details())
        self._saved_iids = {}
        self._render_saved_list()
        search.focus_set()

    def _hide_saved_window(self):
        if self._commit_or_discard_editor():
            self.saved_win.withdraw()

    def _commit_or_discard_editor(self):
        if not getattr(self, "_editor_dirty", False):
            return True
        answer = runtime.messagebox.askyesnocancel(runtime.APP_NAME, "Зберегти зміни до картки?", parent=self.saved_win)
        if answer is None:
            return False
        if answer:
            return self.save_saved_details()
        self._editor_dirty = False
        return True

    def _saved_tree_click(self, event):
        iid = self.saved_tree.identify_row(event.y)
        if iid and self.saved_tree.identify_column(event.x) == "#1":
            word = self._saved_iids[iid]
            var = self._saved_check_var(word)
            var.set(not var.get())
            self._update_selected_count()
            return "break"

    def _saved_tree_select(self, _event=None):
        selection = self.saved_tree.selection()
        if selection:
            word = self._saved_iids.get(selection[0])
            if word and word != self._editor_word:
                if self._commit_or_discard_editor():
                    self.show_saved_details(word)
                elif self._editor_word:
                    self.saved_tree.selection_set(self._saved_tree_id(self._editor_word))

    def _open_selected_popup(self):
        selection = self.saved_tree.selection()
        if selection:
            self.open_saved_word(self._saved_iids[selection[0]])

    @staticmethod
    def _saved_tree_id(word):
        return runtime.hashlib.sha256(word.lower().encode()).hexdigest()

    def show_saved_details(self, word):
        entry = runtime.saved_entry(word)
        if not entry:
            return
        self._loading_editor = True
        self._editor_word = word
        self._editor_dirty = False
        for child in self.saved_list_frame.winfo_children():
            child.destroy()
        frame = self.saved_list_frame
        runtime.ttk.Label(frame, text=word, font=(runtime.FONT, 27, "bold"), wraplength=500).pack(anchor="w", padx=12, pady=8)
        buttons = runtime.ttk.Frame(frame)
        buttons.pack(fill="x", padx=12)
        runtime.ttk.Button(buttons, text="Зберегти (Ctrl+S)", style="Accent.TButton", command=self.save_saved_details).pack(side="left")
        runtime.ttk.Button(buttons, text="Озвучити", command=lambda: self.speak_saved_word(word)).pack(side="left", padx=6)
        runtime.ttk.Button(buttons, text="Видалити", command=lambda: self.delete_saved_word(word)).pack(side="right")
        self.editor_message = runtime.tk.StringVar(value="Зміни зберігаються кнопкою або Ctrl+S.")
        runtime.ttk.Label(frame, textvariable=self.editor_message, wraplength=500).pack(anchor="w", padx=12, pady=6)
        row = runtime.ttk.Frame(frame)
        row.pack(fill="x", padx=12, pady=6)
        runtime.ttk.Label(row, text="Стан:").pack(side="left")
        states = {k: v for k, v in runtime.STATUS_LABELS.items() if v != "all"}
        inverse = {v: k for k, v in states.items()}
        self.editor_status = runtime.tk.StringVar(value=inverse.get(entry.get("status", "new"), "Нові"))
        runtime.ttk.Combobox(row, textvariable=self.editor_status, values=list(states), width=12,
                     state="readonly").pack(side="left", padx=6)
        self.editor_status.trace_add("write", self._mark_editor_dirty)
        self.editor_fields = {}
        labels = (("translation", "Переклад"), ("definition", "Визначення англійською"),
                  ("definition_tr", "Переклад визначення"), ("example", "Приклад"),
                  ("context", "Речення з гри / контекст"), ("context_tr", "Переклад контексту"),
                  ("source", "Джерело / гра"), ("notes", "Власні нотатки"))
        for key, label in labels:
            runtime.ttk.Label(frame, text=label.upper(), foreground="#a2a8b8", font=(runtime.FONT, 9)).pack(anchor="w", padx=12, pady=(14, 5))
            text = runtime.tk.Text(frame, height=3 if key == "notes" else 2, width=48, wrap="word",
                           font=(runtime.FONT, 14 if key == "translation" else 11), undo=True,
                           bg="#1d2029", fg="#f1f1f5", insertbackground="#ffd43b",
                           selectbackground="#ffd43b", selectforeground="#111318",
                           relief="flat", bd=0, padx=12, pady=10, highlightthickness=0)
            text.pack(fill="x", padx=12)
            text.insert("1.0", entry.get(key, ""))
            text.edit_modified(False)
            text.bind("<<Modified>>", self._mark_editor_dirty)
            self.editor_fields[key] = text
        image_buttons = runtime.ttk.Frame(frame)
        image_buttons.pack(fill="x", padx=12, pady=10)
        runtime.ttk.Button(image_buttons, text="Додати зображення…", command=self.replace_saved_image).pack(side="left")
        runtime.ttk.Button(image_buttons, text="Відкрити зображення", command=self.open_saved_image).pack(side="left", padx=6)
        self.editor_photo = runtime.context_photo(entry.get("image_file", ""), self.saved_win, size=(480, 250))
        if self.editor_photo:
            label = runtime.ttk.Label(frame, image=self.editor_photo, cursor="hand2")
            label.pack(anchor="w", padx=12, pady=8)
            label.bind("<Button-1>", lambda _e: self.open_saved_image())
        self._loading_editor = False
        self._editor_dirty = False
        iid = self._saved_tree_id(word)
        if self.saved_tree.exists(iid):
            self.saved_tree.selection_set(iid)

    def _mark_editor_dirty(self, event=None, *_):
        # Text генерує <<Modified>> і при скиданні прапорця: обробляємо лише зміни.
        if event is not None and hasattr(event, "widget"):
            if not event.widget.edit_modified():
                return
            event.widget.edit_modified(False)
        if not self._loading_editor:
            self._editor_dirty = True
            self.editor_message.set("Є незбережені зміни.")

    def save_saved_details(self):
        if not self._editor_word or not hasattr(self, "editor_fields"):
            return True
        fields = {k: text.get("1.0", "end-1c") for k, text in self.editor_fields.items()}
        fields["status"] = runtime.STATUS_LABELS[self.editor_status.get()]
        try:
            runtime.update_saved_entry(self._editor_word, fields)
        except (OSError, ValueError) as e:
            self.editor_message.set(str(e))
            return False
        self._editor_dirty = False
        self.editor_message.set("Збережено")
        self._render_saved_list()
        return True

    def replace_saved_image(self):
        if not self._commit_or_discard_editor():
            return
        path = runtime.filedialog.askopenfilename(parent=self.saved_win, title="Зображення контексту",
                                          filetypes=[("Зображення", "*.png *.jpg *.jpeg *.webp *.bmp")])
        if not path:
            return
        name = ""
        try:
            from PIL import Image
            with Image.open(path) as image:
                name = runtime.save_context_image(image)
            if not name:
                raise OSError("Не вдалося записати зображення")
            entry = runtime.saved_entry(self._editor_word)
            old = runtime.context_image_path(entry.get("image_file", ""))
            runtime.update_saved_entry(self._editor_word, {"image_file": name})
            if old and not runtime.context_image_in_use(runtime.os.path.basename(old)):
                try:
                    runtime.os.remove(old)
                except OSError:
                    runtime.log_exc('word_lookup.replace_saved_image')
            self.show_saved_details(self._editor_word)
        except (OSError, ValueError) as e:
            if name and not any(e.get("image_file") == name for e in runtime.load_saved_words()):
                try:
                    runtime.os.remove(runtime.context_image_path(name))
                except OSError:
                    runtime.log_exc('word_lookup.replace_saved_image')
            self.editor_message.set(f"Зображення не додано: {e}")

    def open_saved_image(self):
        entry = runtime.saved_entry(self._editor_word) if self._editor_word else None
        path = runtime.context_image_path(entry.get("image_file", "")) if entry else None
        if path and runtime.os.path.isfile(path):
            runtime.open_file(path)
        elif hasattr(self, "editor_message"):
            self.editor_message.set("У цієї картки ще немає зображення.")

    def speak_saved_word(self, word):
        entry = runtime.saved_entry(word)
        audios = entry.get("dictionary", {}).get("audios", []) if entry else []
        if audios and runtime.AUDIO_OK:
            runtime.play_audio(audios[0][1])
        else:
            self.editor_message.set("Озвучення відсутнє або pygame не встановлений.")

    def sync_saved_to_anki(self):
        if not self._commit_or_discard_editor():
            return
        entries = [e for e in runtime.load_saved_words() if self._saved_check_var(e["word"]).get()]
        entries = runtime.copy.deepcopy(entries or self._visible_saved_words())
        if not entries:
            self.anki_sync_status.set("Немає слів для передавання")
            return
        deck = runtime.cfg["anki"]["deck"]
        self.anki_sync_btn.state(["disabled"])
        self.anki_sync_status.set(f"Передаю {len(entries)} записів у Anki…")
        def worker():
            try:
                runtime.events.put(("anki_sync_done", runtime.sync_anki_entries(entries, deck), ""))
            except Exception as e:
                runtime.events.put(("anki_sync_done", None, str(e)))
        runtime.threading.Thread(target=worker, daemon=True).start()

    def _saved_check_var(self, word: str):
        key = word.lower()
        var = self.saved_checks.get(key)
        if var is None:
            var = runtime.tk.BooleanVar(value=False)
            self.saved_checks[key] = var
        return var

    def _update_selected_count(self):
        n = sum(1 for e in runtime.load_saved_words() if self._saved_check_var(e["word"]).get())
        if hasattr(self, "saved_selected_var"):
            shown = len(self._visible_saved_words())
            self.saved_selected_var.set(f"Знайдено: {shown} · Обрано: {n}")
        if hasattr(self, "saved_tree"):
            for iid, word in self._saved_iids.items():
                self.saved_tree.set(iid, "check", "☑" if self._saved_check_var(word).get() else "☐")

    def review_saved_words(self):
        if not self._commit_or_discard_editor():
            return
        selected = [e for e in runtime.load_saved_words() if self._saved_check_var(e["word"]).get()]
        entries = selected or self._visible_saved_words()
        if not entries:
            self.toast("Спочатку збережи слова або зміни запит пошуку")
            return
        self.review_window = runtime.ReviewWindow(self, entries)

    def _visible_saved_words(self):
        order = {"Спочатку нові": "newest", "Спочатку старі": "oldest", "За абеткою": "az"}
        entries = runtime.filter_saved_words(runtime.load_saved_words(), self.saved_query.get(),
                                      order.get(self.saved_order.get(), "newest"))
        state = runtime.STATUS_LABELS[self.saved_state_filter.get()]
        return [e for e in entries if (state == "all" or e.get("status", "new") == state)
                and (not self.saved_due_only.get() or runtime.review_due(e))]

    def select_all_saved(self, value: bool):
        for e in self._visible_saved_words() if value else runtime.load_saved_words():
            self._saved_check_var(e.get("word", "")).set(value)
        self._update_selected_count()

    def export_anki_selected(self):
        self._export_saved("txt")

    def export_anki_apkg_selected(self):
        self._export_saved("apkg")

    def _export_saved(self, kind):
        if not self._commit_or_discard_editor():
            return
        selected = [e for e in runtime.load_saved_words()
                   if self._saved_check_var(e.get("word", "")).get()]
        if not selected:
            self.toast("Спочатку познач слова прапорцями")
            return
        if kind == "apkg":
            if not runtime.apkg_available():
                runtime.messagebox.showinfo(
                    runtime.APP_NAME,
                    "Для готового файлу колоди (.apkg) потрібна додаткова бібліотека, якої зараз "
                    "немає в цьому Python:\n\n"
                    f'"{runtime.sys.executable}" -m pip install genanki\n\n'
                    "Постав її й спробуй ще раз. А поки що можна скористатись кнопкою "
                    "«→ Anki (.txt)» — вона працює без додаткових бібліотек.")
                return
            path = runtime.filedialog.asksaveasfilename(
                title="Експорт в Anki (готова колода)", defaultextension=".apkg",
                filetypes=[("Колода Anki", "*.apkg"), ("Усі файли", "*.*")],
                initialfile="word_lookup_anki.apkg")
        else:
            path = runtime.filedialog.asksaveasfilename(
                title="Експорт в Anki", defaultextension=".txt",
                filetypes=[("Текстовий файл для Anki", "*.txt"), ("Усі файли", "*.*")],
                initialfile="word_lookup_anki.txt")
        if not path:
            return
        need = sum(1 for e in selected if runtime._needs_enrich(e))
        if need:  # старі слова без пояснень — дотягуємо (мережа), тож у фоновому потоці
            self.toast(f"Підтягую переклад і пояснення для {need} слів — зачекай…", timeout=20)
        runtime.threading.Thread(target=self._export_worker, args=(kind, selected, path),
                         daemon=True).start()

    def _export_worker(self, kind, selected, path):
        err = ""
        try:
            runtime.enrich_entries(selected)
            (runtime.export_anki_apkg if kind == "apkg" else runtime.export_anki_txt)(selected, path)
        except Exception as e:
            err = f"{type(e).__name__}: {e}"
        runtime.events.put(("export_done", kind, len(selected), path, err))

    def _export_finished(self, kind, n, path, err):
        if hasattr(self, "saved_list_frame"):  # у списку з'являться дотягнуті переклади
            try:
                self._render_saved_list()
            except runtime.tk.TclError:
                runtime.log_exc('word_lookup._export_finished')
        if err:
            self.toast(f"Не вдалося створити файл: {err}", timeout=6)
            return
        if kind == "apkg":
            self.toast(f"Створено колоду з {n} слів — відкрий файл подвійним кліком, "
                       "Anki додасть картки сама", timeout=6)
            return
        try:
            with open(path, encoding="utf-8") as f:
                rows = [ln.rstrip("\n") for ln in f if not ln.startswith("#") and ln.strip()]
        except OSError:
            rows = []
        preview = "\n".join((r if len(r) <= 110 else r[:107] + "…") for r in rows[:3])
        runtime.messagebox.showinfo(
            runtime.APP_NAME,
            f"Збережено {n} слів:\n{path}\n\nПерші рядки файлу (слово ⇥ зворотна сторона):\n"
            f"{preview}\n\nУ вікні імпорту Anki перевір блок зіставлення полів: «Зворотна "
            "сторона» (Back) має бути прив'язана до стовпця 2. Якщо цих слів у колоді вже "
            "є — видали старі картки або вибери оновлення існуючих нотаток, інакше Anki "
            "може їх пропустити й зворотна сторона лишиться порожньою.")

    def _render_saved_list(self):
        self.library_title.set(f"Бібліотека · {len(runtime.load_saved_words())} слів")
        selected = self.saved_tree.selection()
        previous = self._saved_iids.get(selected[0]) if selected else self._editor_word
        self.saved_tree.delete(*self.saved_tree.get_children())
        self._saved_iids = {}
        inverse = {v: k for k, v in runtime.STATUS_LABELS.items()}
        for entry in self._visible_saved_words():
            word = entry["word"]
            iid = self._saved_tree_id(word)
            if iid in self._saved_iids:
                continue
            self._saved_iids[iid] = word
            self.saved_tree.insert("", "end", iid=iid, values=(
                "☑" if self._saved_check_var(word).get() else "☐", word,
                entry.get("translation", ""), inverse.get(entry.get("status", "new"), "Нові"),
                entry.get("source", "")))
        if previous and self.saved_tree.exists(self._saved_tree_id(previous)):
            self.saved_tree.selection_set(self._saved_tree_id(previous))
            if previous == self._editor_word and not self._editor_dirty and hasattr(self, "editor_status"):
                self._loading_editor = True
                entry = runtime.saved_entry(previous)
                self.editor_status.set(inverse.get(entry.get("status", "new"), "Нові"))
                self._loading_editor = False
        elif self.saved_tree.get_children() and not self._editor_dirty:
            self.saved_tree.selection_set(self.saved_tree.get_children()[0])
        if not runtime.load_saved_words():
            for child in self.saved_list_frame.winfo_children():
                child.destroy()
            self._editor_word = None
            self._editor_dirty = False
            runtime.ttk.Label(self.saved_list_frame, text="Бібліотека порожня. Натисни ⭐ у картці слова чи фрази.",
                      wraplength=450).pack(padx=12, pady=20)
        self._update_selected_count()

    def open_saved_word(self, word):
        entry = runtime.saved_entry(word)
        if entry is not None:
            self._new_token()
            self.show_lookup(runtime.saved_word_card(entry), None)

    def delete_saved_word(self, word):
        if not runtime.remove_saved_word(word):
            self.toast("Не вдалося видалити запис; перевір журнал і доступ до файлу")
            return
        self.saved_checks.pop(word.lower(), None)
        if getattr(self, "_editor_word", None) == word:
            self._editor_word = None
            self._editor_dirty = False
        self.refresh_saved_count()
