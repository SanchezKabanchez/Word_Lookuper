"""Frozen-screen OCR selection with keyboard and pointer navigation."""
from __future__ import annotations

runtime = None


def configure(application):
    global runtime
    runtime = application


def _cancel_view_timers(win):
    """Remove delayed overlay callbacks before Tcl deletes their commands."""
    commands = set(win._tclCommands or ())
    for timer in win.tk.call("after", "info"):
        script = win.tk.call("after", "info", timer)[0]
        if win.tk.splitlist(script)[0] in commands:
            win.after_cancel(timer)


class WordNavigator:
    """Reading-order words and geometry for selection without cursor movement."""

    def __init__(self, words):
        self.lines = []
        for line in runtime.cluster_lines(words):
            hits = []
            line_text = " ".join(w.text for w in line)
            for word in line:
                cleaned, lead, trail = runtime.clean_word(word.text)
                if cleaned:
                    width = word.x1 - word.x0
                    hits.append({"word": cleaned, "line_text": line_text,
                                 "box": (int(word.x0 + width * lead), int(word.y0),
                                         int(word.x1 - width * trail), int(word.y1))})
            if hits:
                self.lines.append(hits)
        self.row = self.column = 0
        self.preferred_x = self._center(self.current) if self.current else None

    @staticmethod
    def _center(hit):
        return (hit["box"][0] + hit["box"][2]) / 2

    @property
    def current(self):
        return self.lines[self.row][self.column] if self.lines else None

    def move(self, key):
        if not self.lines:
            return None
        if key in ("left", "right"):
            self.column = max(0, min(self.column + (-1 if key == "left" else 1),
                                     len(self.lines[self.row]) - 1))
            self.preferred_x = self._center(self.current)
        elif key in ("up", "down"):
            self.row = max(0, min(self.row + (-1 if key == "up" else 1), len(self.lines) - 1))
            self.column = min(range(len(self.lines[self.row])),
                              key=lambda i: abs(self._center(self.lines[self.row][i]) - self.preferred_x))
        return self.current


class RegionSelector:
    """Frozen screenshot with word/line keyboard navigation and pointer selection.

    OCR runs on the captured frame in a worker. Global keyboard input is queued
    for Tk, so navigation also works when a game retains keyboard focus.
    """

    HOVER_DELAY_MS = 150  # слово розпізнається, коли курсор на мить зупинився

    def __init__(self, app, on_done):
        self.on_done, self.start, self.done = on_done, None, False
        self.hover_hit, self.mouse = None, (-9999, -9999)
        self._after_id, self._req, self._busy = None, None, False
        self._lock, self._hq = runtime.threading.Lock(), runtime.queue.Queue()
        self.navigator = None
        self.profile = dict(getattr(app, "_lookup_profile", {}) or {})
        mode = self.profile.get("selection_mode", runtime.cfg["freeze"].get("selection_mode", "keyboard"))
        self.keyboard_enabled = mode == "keyboard"
        self._manager = app.manager
        self._key_callback = self._queue_key
        self._prev_hwnd = runtime._foreground_window()  # повернути фокус грі після закриття
        r = app.root
        try:
            x, y = r.winfo_vrootx(), r.winfo_vrooty()
            w, h = r.winfo_vrootwidth(), r.winfo_vrootheight()
            if w < 100 or h < 100:
                raise ValueError
        except Exception:
            x, y, w, h = 0, 0, r.winfo_screenwidth(), r.winfo_screenheight()
        self.w, self.h = w, h
        self.ox, self.oy = x, y  # початок віртуального екрана: екранні координати -> координати полотна
        self.frozen = None  # (img, ox, oy) — заповниться нижче, якщо знімок вдався

        self.win = win = runtime.tk.Toplevel(r)
        win.overrideredirect(True)
        win.attributes("-topmost", True)
        win.configure(bg="#111318")
        win.geometry(f"{w}x{h}+{x}+{y}")
        c = self.canvas = runtime.tk.Canvas(win, bg="#111318", highlightthickness=0, cursor="arrow")
        c.pack(fill="both", expand=True)

        frozen_ok = False
        try:
            from PIL import ImageTk
            shot_img, sx0, sy0, *_ = runtime._grab(x, y, x + w, y + h)
            app._resume_game()
            self._photo = ImageTk.PhotoImage(shot_img, master=win)  # тримаємо посилання — інакше Tk «забуде» картинку
            c.create_image(0, 0, image=self._photo, anchor="nw")
            self.frozen = (shot_img, sx0, sy0)
            frozen_ok = True
        except Exception as e:
            app._resume_game()
            runtime.log(f"Стоп-кадр не вдався, буде звичайне затемнення: {type(e).__name__}: {e}")
            try:
                win.attributes("-alpha", 0.32)
            except runtime.tk.TclError:
                runtime.log_exc('word_lookup.__init__')

        self.hover_enabled = (not self.keyboard_enabled and
                              bool(runtime.cfg["freeze"].get("hover_highlight", True)) and
                              self.frozen is not None)
        hl_color = runtime.cfg["popup"]["highlight_color"]
        self.hl_rect = c.create_rectangle(0, 0, 0, 0, fill=hl_color, stipple="gray50", outline=hl_color,
                                          state="hidden")  # підсвітка слова під курсором
        self.vline = c.create_line(0, 0, 0, h, fill="#ffd43b", state="hidden")  # перехрестя вимкнено:
        self.hline = c.create_line(0, 0, w, 0, fill="#ffd43b", state="hidden")  # курсор — звичайна стрілка
        self.rect = c.create_rectangle(0, 0, 0, 0, outline="#ffd43b", width=2, state="hidden")
        self.size = c.create_text(0, 0, text="", fill="#ffd43b", anchor="sw",
                                  font=(runtime.FONT, 11, "bold"), state="hidden")
        hint = ("⏸ Стоп-кадр — екран заморожено, підказки (тултіпи) нікуди не зникнуть.  "
                if frozen_ok else "") + \
               ("Розпізнаю слова…  ·  ←/→ — слова  ·  ↑/↓ — рядки  ·  Enter — картка  ·  Esc — скасувати"
                if self.keyboard_enabled else
                "Наведи курсор на слово — воно підсвітиться  ·  клік лівою кнопкою — шукати  ·  "
                "або обведи рамкою кілька слів  ·  Esc / права кнопка — скасувати"
                if self.hover_enabled else
                "Тягни рамку навколо слова чи рядка  ·  клік — одне слово  ·  Esc / права кнопка — скасувати")
        if app._game_pause is not None and app._game_pause.active:
            hint = "⏸ Процес гри призупинений · Esc — відновити.  " + hint
        self.hint = c.create_text(-x + r.winfo_screenwidth() // 2, -y + 34, fill="#f1f1f5",
                                 font=(runtime.FONT, 13, "bold"), text=hint,
                                 width=r.winfo_screenwidth() - 80)
        c.bind("<Motion>", self._motion)
        c.bind("<ButtonPress-1>", self._press)
        c.bind("<B1-Motion>", self._drag)
        c.bind("<ButtonRelease-1>", self._release)
        c.bind("<Button-3>", lambda _e: self.finish(None))
        win.bind("<Escape>", lambda _e: self.finish(None))
        win.focus_force()
        c.focus_set()
        win.after(50, self._poll)
        if not self.keyboard_enabled:
            runtime.release_cursor_clip()
            win.after(100, self._unclip_tick)
        if self.keyboard_enabled:
            if self.frozen is not None:
                runtime.threading.Thread(target=self._keyboard_ocr, daemon=True).start()
            else:
                self._set_keyboard_status("Не вдалося зробити стоп-кадр. Esc — скасувати; можна виділити мишею.")
            self._manager.start_raw_mode(self._key_callback)

    def _queue_key(self, name):
        resume = runtime.cfg["hotkeys"].get("resume_game", "")
        if resume and frozenset(self._manager.down) == frozenset(resume.split("+")):
            name = "esc"
        self._hq.put(("key", name))

    def _keyboard_ocr(self):
        """Read the frozen frame once; never capture a newer screen here."""
        image, x, y = self.frozen
        try:
            with runtime.profile_scope(self.profile):
                words = runtime.ocr_region(x, y, x + image.width, y + image.height, frozen=self.frozen)
            self._hq.put(("words", words))
        except Exception as exc:
            runtime.log_exc("Розпізнавання слів для клавіатури")
            self._hq.put(("error", str(exc)))

    def _set_keyboard_status(self, text):
        self.canvas.itemconfigure(self.hint, text=text)

    def _show_keyboard_word(self):
        hit = self.navigator.current if self.navigator else None
        if hit:
            self._set_hover(hit)
            self._set_keyboard_status(
                f"←/→ — слова  ·  ↑/↓ — рядки  ·  Enter — картка  ·  Esc — скасувати\n"
                f"Рядок {self.navigator.row + 1}/{len(self.navigator.lines)}: {hit['line_text']}")

    def key(self, name):
        if self.done:
            return
        if name == "esc":
            self.finish(None)
        elif name == "enter" and self.navigator and self.navigator.current:
            hit = self.navigator.current
            x = (hit["box"][0] + hit["box"][2]) // 2
            y = (hit["box"][1] + hit["box"][3]) // 2
            self.finish(("word", x, y, hit))
        elif name in ("left", "right", "up", "down") and self.navigator:
            self.navigator.move(name)
            self._show_keyboard_word()

    def _unclip_tick(self):
        """Деякі ігри самі повертають обмеження курсора — відпускаємо знову, поки накладка відкрита."""
        if self.done:
            return
        runtime.release_cursor_clip()
        try:
            self.win.after(100, self._unclip_tick)
        except Exception:
            runtime.log_exc('word_lookup._unclip_tick')

    # ---------- підсвітка слова під курсором ----------
    @staticmethod
    def _inside(box, x, y, margin=4) -> bool:
        return box[0] - margin <= x <= box[2] + margin and box[1] - margin <= y <= box[3] + margin

    def _clear_hover(self):
        self.hover_hit = None
        self.canvas.itemconfigure(self.hl_rect, state="hidden")

    def _set_hover(self, hit):
        self.hover_hit = hit
        bx0, by0, bx1, by1 = hit["box"]
        self.canvas.coords(self.hl_rect, bx0 - self.ox - 2, by0 - self.oy - 1,
                           bx1 - self.ox + 2, by1 - self.oy + 1)
        self.canvas.itemconfigure(self.hl_rect, state="normal")

    def _motion(self, e):
        self.mouse = (e.x_root, e.y_root)
        if not self.hover_enabled or self.start:  # під час перетягування рамки не розпізнаємо
            return
        if self.hover_hit and not self._inside(self.hover_hit["box"], e.x_root, e.y_root):
            self._clear_hover()
        if self.hover_hit is None:
            if self._after_id is not None:
                try:
                    self.win.after_cancel(self._after_id)
                except Exception:
                    runtime.log_exc('word_lookup._motion')
            x, y = e.x_root, e.y_root
            self._after_id = self.win.after(self.HOVER_DELAY_MS, lambda: self._request(x, y))

    def _request(self, x, y):
        self._after_id = None
        if self.done:
            return
        with self._lock:
            self._req = (x, y)
            spawn = not self._busy
            self._busy = True
        if spawn:
            runtime.threading.Thread(target=self._ocr_worker, daemon=True).start()

    def _ocr_worker(self):
        """Один фоновий потік: бере лише НАЙНОВІШИЙ запит, старі пропускає."""
        while True:
            with self._lock:
                req, self._req = self._req, None
                if req is None:
                    self._busy = False
                    return
            try:
                with runtime.profile_scope(self.profile):
                    hit = runtime.find_word_at(req[0], req[1], frozen=self.frozen)
            except Exception:
                runtime.log_exc("Підсвічування слова на стоп-кадрі")
                hit = None
            self._hq.put(("hover", req, hit))

    def _poll(self):
        if self.done:
            return
        latest = None
        while True:
            try:
                item = self._hq.get_nowait()
            except runtime.queue.Empty:
                break
            if item[0] == "hover":
                latest = item[1:]
            elif item[0] == "words":
                self.navigator = WordNavigator(item[1])
                if self.navigator.current:
                    self._show_keyboard_word()
                else:
                    self._set_keyboard_status("Слів не знайдено. Esc — скасувати; можна виділити мишею.")
            elif item[0] == "error":
                self._set_keyboard_status(f"Помилка OCR: {item[1]}  ·  Esc — скасувати")
            elif item[0] == "key":
                self.key(item[1])
                if self.done:
                    return
        if latest is not None:
            (rx, ry), hit = latest
            mx, my = self.mouse
            if abs(rx - mx) <= 12 and abs(ry - my) <= 12:  # відповідь ще актуальна
                if hit:
                    self._set_hover(hit)
                else:
                    self._clear_hover()
        try:
            self.win.after(50, self._poll)
        except Exception:
            runtime.log_exc('word_lookup._poll')

    def _move(self, e):
        self.canvas.coords(self.vline, e.x, 0, e.x, self.h)
        self.canvas.coords(self.hline, 0, e.y, self.w, e.y)

    def _press(self, e):
        self.start = (e.x, e.y, e.x_root, e.y_root)
        self.canvas.itemconfigure(self.rect, state="normal")

    def _drag(self, e):
        self._move(e)
        if self.start:
            sx, sy = self.start[:2]
            self.canvas.coords(self.rect, sx, sy, e.x, e.y)
            self.canvas.coords(self.size, min(sx, e.x), min(sy, e.y) - 4)
            self.canvas.itemconfigure(self.size, text=f"{abs(e.x - sx)}×{abs(e.y - sy)}",
                                      state="normal")

    def _release(self, e):
        if not self.start:
            return
        x0, x1 = sorted((self.start[2], e.x_root))
        y0, y1 = sorted((self.start[3], e.y_root))
        if x1 - x0 < 6 and y1 - y0 < 6:
            hit = self.hover_hit
            if hit and self._inside(hit["box"], e.x_root, e.y_root):
                self.finish(("word", e.x_root, e.y_root, hit))  # слово вже розпізнано — без повторного OCR
            else:
                self.finish(("point", e.x_root, e.y_root))
        else:
            self.finish(("rect", x0, y0, x1, y1))

    def finish(self, result):
        if self.done:
            return
        self.done = True
        if self._manager.raw_mode_cb is self._key_callback:
            self._manager.stop_raw_mode()
        frozen = self.frozen
        if getattr(self, "_after_id", None) is not None:
            try:
                self.win.after_cancel(self._after_id)
            except Exception:
                runtime.log_exc('word_lookup.finish')
        try:
            _cancel_view_timers(self.win)
            self.win.destroy()
        except Exception:
            runtime.log_exc('word_lookup.finish')
        runtime._restore_foreground(self._prev_hwnd)
        self.on_done(result, frozen)


